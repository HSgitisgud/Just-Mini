package com.justmini.minidungeon;

public class Goblin extends Monster {

    public Goblin(int x, int y) {
        super(x, y, "goblin", 50, 15, 5, 20, "/images/goblin.png");
    }
}
