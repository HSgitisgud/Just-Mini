package com.justmini.minidungeon;

public class Slime extends Monster {

    public Slime(int x, int y) {
        super(x, y, "slime", 30, 10, 2, 10, "/images/slime.png");
    }
}
